/**
 * ============================================
 * VocalCleaner — Proxy Backend Server
 * ============================================
 * 
 * Bu server, frontend ile Cleanvoice AI API arasında güvenli bir
 * proxy görevi görür. API anahtarını gizli tutar ve CORS sorunlarını çözer.
 * 
 * Cleanvoice API İş Akışı:
 *   1. POST /v2/upload?filename=...  → Signed URL al
 *   2. PUT  signedUrl                → Dosyayı yükle
 *   3. POST /v2/edits                → İşleme job'ı oluştur
 *   4. GET  /v2/edits/{id}           → Durumu polling ile kontrol et
 *   5. download_url                  → Temiz sesi indir
 * 
 * Kurulum:
 *   1. .env dosyasına CLEANVOICE_API_KEY= ekleyin
 *   2. npm install
 *   3. npm start (veya npm run dev)
 */

const express = require('express');
const multer = require('multer');
const cors = require('cors');
const path = require('path');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3456;

// ===== CLEANVOICE API AYARLARI =====
const CLEANVOICE_BASE_URL = 'https://api.cleanvoice.ai/v2';
const CLEANVOICE_API_KEY = process.env.CLEANVOICE_API_KEY;

// ===== MIDDLEWARE =====
app.use(cors());
app.use(express.json());

// ===== AUPHONIC API AYARLARI =====
const AUPHONIC_BASE_URL = 'https://auphonic.com/api';
const AUPHONIC_USER = process.env.AUPHONIC_USER;
const AUPHONIC_PASS = process.env.AUPHONIC_PASS;

// İşlem zincirlerini takip etmek için bellek içi depo
const inProgressChains = {};

// Statik dosyaları sun (index.html, style.css, app.js)
app.use(express.static(path.join(__dirname)));

// Multer — bellek üzerinde dosya kabul et (max 50MB)
const upload = multer({
    storage: multer.memoryStorage(),
    limits: { fileSize: 50 * 1024 * 1024 }, // 50MB
    fileFilter: (req, file, cb) => {
        const allowed = ['audio/mpeg', 'audio/wav', 'audio/x-wav', 'audio/mp3'];
        const ext = file.originalname.split('.').pop().toLowerCase();
        if (allowed.includes(file.mimetype) || ['mp3', 'wav'].includes(ext)) {
            cb(null, true);
        } else {
            cb(new Error('Sadece MP3 ve WAV formatları destekleniyor.'));
        }
    },
});

// ===== API KEY KONTROLÜ =====
function checkApiKey() {
    if (!CLEANVOICE_API_KEY || CLEANVOICE_API_KEY === 'your_cleanvoice_api_key_here') {
        return false;
    }
    return true;
}

// ===== ENDPOINT: Ses İyileştirme =====
/**
 * POST /api/enhance
 * 
 * Frontend'den gelen ses dosyasını Cleanvoice API'sine gönderir.
 * Tüm upload → edit → polling → download akışını yönetir.
 * 
 * Request: multipart/form-data (alan: "audio")
 * Response: { downloadUrl: string } veya hata
 */
app.post('/api/enhance', upload.single('audio'), async (req, res) => {
    try {
        // API anahtarı kontrolü
        if (!checkApiKey()) {
            return res.status(500).json({
                error: 'API_KEY_MISSING',
                message: 'CLEANVOICE_API_KEY .env dosyasında tanımlanmamış. Lütfen .env dosyanızı kontrol edin.',
            });
        }

        if (!req.file) {
            return res.status(400).json({
                error: 'NO_FILE',
                message: 'Ses dosyası bulunamadı.',
            });
        }

        const filename = req.file.originalname;
        console.log(`[VocalCleaner] İşlem başlatılıyor: ${filename} (${(req.file.size / 1024 / 1024).toFixed(1)} MB)`);

        // ---------------------------------------------------------------
        // ADIM 1: Cleanvoice'a dosya yükleme için signed URL al
        // ---------------------------------------------------------------
        console.log('[VocalCleaner] Adım 1/4: Signed URL alınıyor...');
        const uploadResponse = await fetch(`${CLEANVOICE_BASE_URL}/upload?filename=${encodeURIComponent(filename)}`, {
            method: 'POST',
            headers: {
                'X-API-Key': CLEANVOICE_API_KEY,
            },
        });

        if (!uploadResponse.ok) {
            const errorText = await uploadResponse.text();
            console.error('[VocalCleaner] Upload URL hatası:', uploadResponse.status, errorText);
            throw new Error(`Cleanvoice upload URL hatası: ${uploadResponse.status} - ${errorText}`);
        }

        const uploadData = await uploadResponse.json();
        const signedUrl = uploadData.signedUrl;
        console.log('[VocalCleaner] Signed URL alındı.');

        // ---------------------------------------------------------------
        // ADIM 2: Dosyayı signed URL'e yükle (PUT)
        // ---------------------------------------------------------------
        console.log('[VocalCleaner] Adım 2/4: Dosya yükleniyor...');
        const putResponse = await fetch(signedUrl, {
            method: 'PUT',
            headers: {
                'Content-Type': req.file.mimetype || 'application/octet-stream',
            },
            body: req.file.buffer,
        });

        if (!putResponse.ok) {
            const errorText = await putResponse.text();
            console.error('[VocalCleaner] Dosya yükleme hatası:', putResponse.status, errorText);
            throw new Error(`Dosya yükleme hatası: ${putResponse.status}`);
        }
        console.log('[VocalCleaner] Dosya başarıyla yüklendi.');

        // Signed URL'den query string'i kaldırarak dosya URL'ini oluştur
        const fileUrl = signedUrl.split('?')[0];

        // Frontend'den gelen şiddet ayarını al
        // multer multipart/form-data işledikten sonra req.body dolar
        const intensity = (req.body && req.body.intensity) ? req.body.intensity.toLowerCase().trim() : 'orta';
        console.log(`[VocalCleaner] Şiddet Seviyesi: "${intensity}" (req.body: ${JSON.stringify(req.body)})`);

        // ---------------------------------------------------------------
        // ADIM 3/4: İşleme job'ı oluştur (POST /v2/edits)
        // ---------------------------------------------------------------
        console.log('[VocalCleaner] Adım 3/4: İşleme job\'ı oluşturuluyor...');

        // Şiddete göre Cleanvoice konfigürasyonunu ayarla
        // NOT: studio_sound "nightly" string olmalı (resmi API docs)
        let apiConfig;

        if (intensity === 'hafif') {
            apiConfig = {
                remove_noise: true,
                normalize: true,
                export_format: 'wav'
            };
        } else if (intensity === 'orta') {
            apiConfig = {
                remove_noise: true,
                normalize: true,
                studio_sound: 'nightly',
                breath: true,
                export_format: 'wav'
            };
        } else {
            apiConfig = {
                remove_noise: true,
                normalize: true,
                studio_sound: 'nightly',
                breath: true,
                mouth_sounds: true,
                fillers: true,
                stutters: true,
                long_silences: true,
                export_format: 'wav'
            };
        }

        // Cleanvoice'a gönderilen konfigürasyonu logla
        console.log('[VocalCleaner] Cleanvoice API Config:', JSON.stringify(apiConfig, null, 2));

        const editPayload = {
            input: {
                files: [fileUrl],
                config: apiConfig
            },
        };

        const editResponse = await fetch(`${CLEANVOICE_BASE_URL}/edits`, {
            method: 'POST',
            headers: {
                'X-API-Key': CLEANVOICE_API_KEY,
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(editPayload),
        });

        if (!editResponse.ok) {
            const errorText = await editResponse.text();
            console.error('[VocalCleaner] Edit oluşturma hatası:', editResponse.status, errorText);
            throw new Error(`Edit oluşturma hatası: ${editResponse.status} - ${errorText}`);
        }

        const editData = await editResponse.json();
        const editId = editData.id;
        console.log(`[VocalCleaner] Edit job oluşturuldu: ${editId}`);

        // İşlem zincirini başlat (Cleanvoice -> Auphonic)
        inProgressChains[editId] = {
            status: 'CLEANVOICE',
            cleanvoiceId: editId,
            auphonicUuid: null,
            finalUrl: null,
            error: null
        };

        // Arka planda zinciri yönet (ASENKRON)
        processMasteringChain(editId).catch(err => {
            console.error(`[VocalCleaner] ❌ Zincirleme işlem hatası (${editId}):`, err.message);
            if (inProgressChains[editId]) {
                inProgressChains[editId].status = 'FAILURE';
                inProgressChains[editId].error = err.message;
            }
        });

        // Hemen editId dön (Frontend polling yapar)
        return res.json({
            success: true,
            editId: editId,
        });

    } catch (error) {
        console.error('[VocalCleaner] ❌ Hata:', error.message);
        return res.status(500).json({
            error: 'PROCESSING_ERROR',
            message: error.message,
        });
    }
});

// ===== ENDPOINT: İşlem Durumu Sorgulama =====
/**
 * GET /api/status/:editId
 * 
 * Frontend'in polling yapması için edit durumunu döndürür.
 * Böylece frontend animasyonu gerçek duruma göre senkronize edebilir.
 */
app.get('/api/status/:editId', async (req, res) => {
    try {
        if (!checkApiKey()) {
            return res.status(500).json({ error: 'API_KEY_MISSING' });
        }

        const { editId } = req.params;

        // Zincirleme işlem durumunu kontrol et
        const chain = inProgressChains[editId];

        if (chain) {
            // Eğer Auphonic aşamasındaysa veya bittiyse özel durum dön
            if (chain.status === 'AUPHONIC' || chain.status === 'AUPHONIC_MASTERING') {
                return res.json({
                    status: 'AUPHONIC_MASTERING', // Frontend bu duruma göre Step 5'i yakalar
                    auphonicUuid: chain.auphonicUuid
                });
            }
            if (chain.status === 'DONE' || chain.status === 'SUCCESS') {
                return res.json({
                    status: 'DONE',
                    downloadUrl: chain.finalUrl // Kullanıcının istediği format
                });
            }
            if (chain.status === 'FAILURE') {
                return res.json({
                    status: 'FAILURE',
                    error: chain.error
                });
            }
        }

        // Zincir henüz Cleanvoice aşamasında, Cleanvoice'dan sor
        const response = await fetch(`${CLEANVOICE_BASE_URL}/edits/${editId}`, {
            headers: { 'X-API-Key': CLEANVOICE_API_KEY },
        });

        if (!response.ok) {
            throw new Error(`Durum sorgulama hatası: ${response.status}`);
        }

        const data = await response.json();
        return res.json(data);

    } catch (error) {
        return res.status(500).json({ error: error.message });
    }
});

// ===== ENDPOINT: İşlenmiş Sesi Proxy İle İndir =====
/**
 * GET /api/download?url=...
 * 
 * Cleanvoice'un döndürdüğü download_url'den sesi indirip
 * frontend'e stream eder. CORS sorununu çözer.
 */
app.get('/api/download', async (req, res) => {
    try {
        const { url } = req.query;
        if (!url) {
            return res.status(400).json({ error: 'URL parametresi gerekli.' });
        }

        console.log('[VocalCleaner] Dosya indiriliyor:', url.substring(0, 80) + '...');

        // Auphonic indirmeleri için yetkilendirme gerekli
        const headers = {
            'User-Agent': 'VocalCleaner-UA'
        };

        if (url.includes('auphonic.com')) {
            const user = process.env.AUPHONIC_USER;
            const pass = process.env.AUPHONIC_PASS;
            
            if (user && pass) {
                const auth = Buffer.from(`${user}:${pass}`).toString('base64');
                headers['Authorization'] = `Basic ${auth}`;
                console.log('[VocalCleaner] Auphonic indirme isteği yetkilendirildi.');
            } else {
                console.warn('[VocalCleaner] Uyarı: Auphonic kimlik bilgileri (.env) bulunamadı!');
            }
        }

        const response = await fetch(url, { headers });
        if (!response.ok) {
            const statusText = response.statusText;
            console.error(`[VocalCleaner] İndirme hatası: ${response.status} ${statusText}`);
            throw new Error(`İndirme hatası: ${response.status} (${statusText})`);
        }

        // Content-Type ve Content-Disposition başlıklarını ayarla
        const contentType = response.headers.get('content-type') || 'audio/wav';
        res.setHeader('Content-Type', contentType);
        res.setHeader('Access-Control-Allow-Origin', '*');

        // Stream olarak aktar
        const arrayBuffer = await response.arrayBuffer();
        res.send(Buffer.from(arrayBuffer));

    } catch (error) {
        console.error('[VocalCleaner] İndirme hatası:', error.message);
        return res.status(500).json({ error: error.message });
    }
});

// ===== ENDPOINT: API Anahtarı Kontrolü =====
/**
 * GET /api/check-key
 * 
 * Frontend'in API anahtarının ayarlanıp ayarlanmadığını kontrol etmesi için.
 */
app.get('/api/check-key', (req, res) => {
    res.json({
        configured: checkApiKey(),
        message: checkApiKey()
            ? 'Cleanvoice API anahtarı yapılandırılmış.'
            : 'CLEANVOICE_API_KEY .env dosyasında tanımlanmamış. Lütfen ayarlayın.',
    });
});

// ===== POLLING HELPER =====
/**
 * Edit job durumunu polling ile kontrol et
 * 
 * Cleanvoice API'si asenkron çalışır:
 *   PENDING → PREPROCESSING → CLASSIFICATION → EDITING → POSTPROCESSING → EXPORT → SUCCESS
 * 
 * ~30sn (2-3dk klip), ~5-10dk (1 saatlik dosya)
 * İlk 30sn bekle, sonra her 10sn'de bir sorgula.
 * 
 * @param {string} editId - Edit job ID
 * @param {number} maxAttempts - Maksimum deneme sayısı (varsayılan: 120 = ~20dk)
 * @returns {Promise<object>} Tamamlanmış edit sonucu
 */
async function pollEditStatus(editId, maxAttempts = 120) {
    // İlk 5 saniye bekle (Cleanvoice minimum işlem süresi)
    console.log('[VocalCleaner] İlk bekleme (5sn)...');
    await new Promise(resolve => setTimeout(resolve, 5000));

    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
        const response = await fetch(`${CLEANVOICE_BASE_URL}/edits/${editId}`, {
            headers: { 'X-API-Key': CLEANVOICE_API_KEY },
        });

        if (!response.ok) {
            console.error(`[VocalCleaner] Polling hatası (deneme ${attempt}):`, response.status);
            await new Promise(resolve => setTimeout(resolve, 5000));
            continue;
        }

        const data = await response.json();
        const status = data.status || data.task_status;

        console.log(`[VocalCleaner] Polling #${attempt}: ${status}`);

        if (status === 'SUCCESS') {
            return data;
        }

        if (status === 'FAILURE' || status === 'FAILED') {
            throw new Error(`Cleanvoice işlemi başarısız oldu. Detay: ${JSON.stringify(data)}`);
        }

        // Her 5 saniyede bir sorgula
        await new Promise(resolve => setTimeout(resolve, 5000));
    }

    throw new Error(`İşlem zaman aşımına uğradı (${maxAttempts} deneme sonrası).`);
}

/**
 * Cleanvoice + Auphonic zincirini yöneten ana fonksiyon
 */
async function processMasteringChain(editId) {
    try {
        // 1. Cleanvoice işleminin bitmesini bekle
        const cvData = await pollEditStatus(editId);
        const cvDownloadUrl = cvData.download_url || cvData.result?.download_url;

        if (!cvDownloadUrl) throw new Error('Cleanvoice download URL bulunamadı.');

        // 2. Auphonic adımına geç
        console.log('[VocalCleaner] Adım 5/5: Auphonic mastering başlatılıyor...');
        inProgressChains[editId].status = 'AUPHONIC_MASTERING';

        const auphonicProduction = await startAuphonicProduction(cvDownloadUrl);
        inProgressChains[editId].auphonicUuid = auphonicProduction.uuid;

        // 3. Auphonic işleminin bitmesini bekle
        const finalData = await pollAuphonicStatus(auphonicProduction.uuid);

        // 4. Zinciri başarıyla tamamla
        inProgressChains[editId].status = 'DONE';
        inProgressChains[editId].finalUrl = finalData.output_files[0].download_url;
        console.log('[VocalCleaner] ✨ Tüm süreç başarıyla tamamlandı (Cleanvoice + Auphonic)');

    } catch (error) {
        console.error(`[VocalCleaner] Zincir hatası (${editId}):`, error.message);
        inProgressChains[editId].status = 'FAILURE';
        inProgressChains[editId].error = error.message;
    }
}

async function startAuphonicProduction(inputUrl) {
    // Kimlik bilgilerini tazeleyerek oku ve logla
    const user = process.env.AUPHONIC_USER;
    const pass = process.env.AUPHONIC_PASS;

    console.log(`[DEBUG] Auphonic credentials check: User=${user ? 'OK' : 'MISSING'}, Pass=${pass ? 'OK' : 'MISSING'}`);

    const authString = `${user}:${pass}`;
    const auth = Buffer.from(authString).toString('base64');
    console.log('[DEBUG] Auphonic auth (Base64):', auth);

    // Production oluştur ve anında başlat (One-shot)
    const payload = {
        input_file: inputUrl,  // URL'i input_file parametresiyle gönderiyoruz
        action: "start",       // İşlemi anında başlat
        algorithms: {
            denoise: true,
            filtering: true,
            normloudness: true,
            loudnesstarget: -16
        },
        output_files: [
            { "format": "wav" }
        ]
    };

    const response = await fetch(`${AUPHONIC_BASE_URL}/productions.json`, {
        method: 'POST',
        headers: {
            'Authorization': `Basic ${auth}`,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
    });

    if (!response.ok) {
        const err = await response.text();
        throw new Error(`Auphonic production oluşturulamadı: ${response.status} - ${err}`);
    }

    const data = await response.json();
    const uuid = data.data.uuid;
    console.log(`[VocalCleaner] Auphonic production oluşturuldu ve otomatik başlatıldı: ${uuid}`);
    return data.data;
}

/**
 * Auphonic Durum Polling
 */
async function pollAuphonicStatus(uuid, maxAttempts = 60) {
    const auth = Buffer.from(`${AUPHONIC_USER}:${AUPHONIC_PASS}`).toString('base64');

    for (let i = 0; i < maxAttempts; i++) {
        const response = await fetch(`${AUPHONIC_BASE_URL}/production/${uuid}.json`, {
            headers: { 'Authorization': `Basic ${auth}` }
        });

        if (!response.ok) {
            console.error(`[VocalCleaner] Auphonic polling hatası: ${response.status}`);
            await new Promise(r => setTimeout(r, 5000));
            continue;
        }

        const resJson = await response.json();
        const data = resJson.data;
        const status = data.status_string; // "Done", "Processing", "Error" vb.

        console.log(`[VocalCleaner] Auphonic Durum (${uuid}): ${status}`);

        if (status === 'Done') {
            return data;
        }
        if (status === 'Error') {
            throw new Error(`Auphonic hatası: ${data.error_message || 'Bilinmeyen hata'}`);
        }

        await new Promise(r => setTimeout(r, 5000));
    }

    throw new Error('Auphonic işlemi zaman aşımına uğradı.');
}

// ===== SERVER BAŞLAT =====
app.listen(PORT, () => {
    console.log('');
    console.log('  ╔══════════════════════════════════════════════════╗');
    console.log('  ║                                                  ║');
    console.log('  ║   🎤 VocalCleaner — AI Ses İyileştirme Stüdyosu  ║');
    console.log('  ║                                                  ║');
    console.log(`  ║   🌐 http://localhost:${PORT}                      ║`);
    console.log('  ║                                                  ║');
    console.log(`  ║   🔑 API Key: ${checkApiKey() ? '✅ Yapılandırılmış' : '❌ Eksik (.env kontrol edin)'}        ║`);
    console.log('  ║                                                  ║');
    console.log('  ╚══════════════════════════════════════════════════╝');
    console.log('');
});